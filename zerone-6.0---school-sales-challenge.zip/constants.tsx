
import { Product, LeaderboardEntry } from './types';

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Smart Keychain',
    price: 5.99,
    description: 'A stylish keychain that reflects light for night safety.',
    imageUrl: 'https://picsum.photos/seed/keychain/400/300'
  },
  {
    id: '2',
    name: 'Eco-Notebook',
    price: 8.50,
    description: '100% recycled paper with a bamboo cover.',
    imageUrl: 'https://picsum.photos/seed/notebook/400/300'
  },
  {
    id: '3',
    name: 'Custom Sticker Pack',
    price: 3.00,
    description: 'Limited edition ZERONE 6.0 stickers.',
    imageUrl: 'https://picsum.photos/seed/stickers/400/300'
  }
];

export const INITIAL_LEADERBOARD: LeaderboardEntry[] = [
  { id: '1', studentName: 'Alex Johnson', points: 1250, salesCount: 42 },
  { id: '2', studentName: 'Maria Garcia', points: 1100, salesCount: 38 },
  { id: '3', studentName: 'Sam Smith', points: 950, salesCount: 31 },
  { id: '4', studentName: 'Jordan Lee', points: 820, salesCount: 25 },
  { id: '5', studentName: 'Taylor Reed', points: 740, salesCount: 19 }
];

export const EVENT_DETAILS = {
  title: "ZERONE 6.0",
  description: "The ultimate school entrepreneurship challenge. Pitch, sell, and win!",
  purpose: "Students are equipped with exclusive products and must use their marketing skills to sell them to earn points and climb the leaderboard.",
  date: "October 15, 2024",
  location: "Main Gymnasium & Courtyard"
};
