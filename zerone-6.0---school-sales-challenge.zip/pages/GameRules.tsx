
import React from 'react';
import { INITIAL_LEADERBOARD } from '../constants';

const GameRules: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 py-16">
      <div className="grid lg:grid-cols-2 gap-16">
        
        {/* Rules Section */}
        <div className="space-y-10">
          <div>
            <h1 className="text-4xl font-extrabold mb-4 tracking-tight">How to Play</h1>
            <p className="text-slate-600 text-lg">ZERONE 6.0 is designed to test your real-world sales and marketing skills. Here is how you score!</p>
          </div>

          <div className="space-y-6">
            <div className="flex gap-6 p-6 bg-white rounded-3xl border border-slate-100 shadow-sm">
              <div className="flex-shrink-0 w-12 h-12 bg-indigo-600 text-white rounded-2xl flex items-center justify-center font-bold text-xl">1</div>
              <div>
                <h3 className="font-bold text-xl mb-2">Pick Your Inventory</h3>
                <p className="text-slate-600">Select products from the catalog that you believe have the most potential in the current school market.</p>
              </div>
            </div>

            <div className="flex gap-6 p-6 bg-white rounded-3xl border border-slate-100 shadow-sm">
              <div className="flex-shrink-0 w-12 h-12 bg-indigo-600 text-white rounded-2xl flex items-center justify-center font-bold text-xl">2</div>
              <div>
                <h3 className="font-bold text-xl mb-2">Market & Sell</h3>
                <p className="text-slate-600">Pitch to your fellow students and faculty. Use social media, posters, or word-of-mouth. Every confirmed sale counts!</p>
              </div>
            </div>

            <div className="flex gap-6 p-6 bg-white rounded-3xl border border-slate-100 shadow-sm">
              <div className="flex-shrink-0 w-12 h-12 bg-indigo-600 text-white rounded-2xl flex items-center justify-center font-bold text-xl">3</div>
              <div>
                <h3 className="font-bold text-xl mb-2">Earn Points</h3>
                <p className="text-slate-600">Points are awarded based on total revenue and the variety of products sold. 10 points per $1 sold!</p>
              </div>
            </div>
          </div>

          <div className="bg-indigo-600 rounded-3xl p-8 text-white">
            <h3 className="text-2xl font-bold mb-4">Pro Tip 💡</h3>
            <p className="opacity-90 leading-relaxed text-lg">
              Bundling products (selling two items together for a slight discount) often leads to higher sales volume and massive bonus points!
            </p>
          </div>
        </div>

        {/* Leaderboard Section */}
        <div className="space-y-8">
          <div className="flex items-center justify-between">
            <h2 className="text-3xl font-bold tracking-tight">Current Leaderboard</h2>
            <span className="flex items-center text-sm font-medium text-green-600 bg-green-50 px-3 py-1 rounded-full">
              <span className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></span>
              Live Updates
            </span>
          </div>

          <div className="bg-white rounded-3xl border overflow-hidden shadow-sm">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-slate-50 border-b">
                  <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Rank</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Student</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Sales</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Points</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {INITIAL_LEADERBOARD.map((entry, index) => (
                  <tr key={entry.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4">
                      {index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : `#${index + 1}`}
                    </td>
                    <td className="px-6 py-4 font-bold text-slate-900">{entry.studentName}</td>
                    <td className="px-6 py-4 text-slate-600">{entry.salesCount} units</td>
                    <td className="px-6 py-4">
                      <span className="font-mono font-bold text-indigo-600">
                        {entry.points.toLocaleString()}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="p-6 border border-dashed rounded-3xl text-center text-slate-500">
            Keep selling to see your name here! <br/>
            Check your personal stats in the dashboard.
          </div>
        </div>

      </div>
    </div>
  );
};

export default GameRules;
