
import React from 'react';
import { Link } from 'react-router-dom';
import { EVENT_DETAILS } from '../constants';
import { Product } from '../types';

interface HomeProps {
  products: Product[];
}

const Home: React.FC<HomeProps> = ({ products }) => {
  return (
    <div className="space-y-20 pb-20">
      {/* Hero Section */}
      <section className="relative h-[600px] flex items-center justify-center overflow-hidden bg-gradient-to-br from-indigo-600 to-purple-700">
        <div className="absolute inset-0 opacity-20">
          <div className="grid grid-cols-6 h-full">
            {[...Array(24)].map((_, i) => (
              <div key={i} className="border border-white/20"></div>
            ))}
          </div>
        </div>
        
        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
          <div className="inline-block px-4 py-1.5 mb-6 bg-white/10 backdrop-blur-md rounded-full border border-white/20 text-white font-medium text-sm animate-bounce">
            Big Event Coming Soon! 🚀
          </div>
          <h1 className="text-5xl md:text-7xl font-extrabold text-white mb-6 leading-tight tracking-tighter">
            {EVENT_DETAILS.title}
          </h1>
          <p className="text-xl md:text-2xl text-indigo-100 mb-10 leading-relaxed max-w-2xl mx-auto">
            {EVENT_DETAILS.description}
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-4">
            <Link to="/products" className="w-full sm:w-auto px-8 py-4 bg-white text-indigo-600 rounded-xl font-bold text-lg hover:shadow-xl hover:scale-105 transition-all">
              View Products
            </Link>
            <Link to="/rules" className="w-full sm:w-auto px-8 py-4 bg-indigo-500 text-white rounded-xl font-bold text-lg hover:bg-indigo-400 transition-all border border-indigo-400">
              How it Works
            </Link>
          </div>
        </div>
      </section>

      {/* Info Section */}
      <section className="max-w-7xl mx-auto px-4 grid md:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <div className="w-12 h-12 bg-indigo-100 text-indigo-600 rounded-2xl flex items-center justify-center">
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <h2 className="text-4xl font-bold text-slate-900 tracking-tight">What is ZERONE 6.0?</h2>
          <p className="text-lg text-slate-600 leading-relaxed">
            {EVENT_DETAILS.purpose}
          </p>
          <div className="grid grid-cols-2 gap-6 pt-4">
            <div className="p-4 bg-white border rounded-2xl shadow-sm">
              <div className="text-sm text-slate-500 mb-1">When</div>
              <div className="font-bold text-slate-900">{EVENT_DETAILS.date}</div>
            </div>
            <div className="p-4 bg-white border rounded-2xl shadow-sm">
              <div className="text-sm text-slate-500 mb-1">Where</div>
              <div className="font-bold text-slate-900">{EVENT_DETAILS.location}</div>
            </div>
          </div>
        </div>
        <div className="relative">
          <img 
            src="https://picsum.photos/seed/event/800/600" 
            alt="Event Atmosphere" 
            className="rounded-3xl shadow-2xl rotate-2 hover:rotate-0 transition-transform duration-500"
          />
          <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-2xl shadow-xl hidden md:block border">
            <div className="text-3xl font-bold text-indigo-600 mb-1">500+</div>
            <div className="text-slate-600 font-medium">Students Participating</div>
          </div>
        </div>
      </section>

      {/* Featured Products Mini Grid */}
      <section className="bg-slate-100 py-20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between items-end mb-12">
            <div>
              <h2 className="text-3xl font-bold mb-2">Cool Stuff to Sell</h2>
              <p className="text-slate-600">Get a sneak peek at what you'll be marketing!</p>
            </div>
            <Link to="/products" className="text-indigo-600 font-semibold hover:underline">View all products →</Link>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {products.slice(0, 3).map(product => (
              <div key={product.id} className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-shadow group">
                <div className="aspect-video relative overflow-hidden">
                  <img 
                    src={product.imageUrl} 
                    alt={product.name} 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="p-6">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-bold text-xl">{product.name}</h3>
                    <span className="bg-indigo-50 text-indigo-600 px-2 py-1 rounded-lg font-bold text-sm">
                      ${product.price.toFixed(2)}
                    </span>
                  </div>
                  <p className="text-slate-600 text-sm line-clamp-2">{product.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
