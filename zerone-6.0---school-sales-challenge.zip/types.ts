
export interface Product {
  id: string;
  name: string;
  price: number;
  description: string;
  imageUrl: string;
}

export interface LeaderboardEntry {
  id: string;
  studentName: string;
  points: number;
  salesCount: number;
}
